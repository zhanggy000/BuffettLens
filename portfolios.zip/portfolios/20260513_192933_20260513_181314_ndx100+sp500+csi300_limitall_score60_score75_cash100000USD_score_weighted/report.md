# Portfolio 20260513_192933_20260513_181314_ndx100+sp500+csi300_limitall_score60_score75_cash100000USD_score_weighted

- Created: 2026-05-13
- Report folder: `reports\20260513_181314_ndx100+sp500+csi300_limitall_score60`
- Min score: 75.0
- Cash: 100000.00 USD
- Allocation method: score_weighted
- Positions: 28

> This is a simulated portfolio for evaluating BuffettLens signals. It is not investment advice.

| Ticker | Name | Score | Price CCY | Buy Price | FX to Base | Shares | Allocated Base | Weight |
|---|---|---:|---|---:|---:|---:|---:|---:|
| HIG | The Hartford Insurance Group, Inc. | 89.0 | USD | 133.1100 | 1.000000 | 30.322900 | 4036.28 | 4.04% |
| ACGL | Arch Capital Group Ltd. | 88.0 | USD | 94.3100 | 1.000000 | 42.317142 | 3990.93 | 3.99% |
| ADBE | Adobe Inc. | 85.0 | USD | 246.1500 | 1.000000 | 15.660676 | 3854.88 | 3.85% |
| 002001.SZ | Zhejiang NHU Company Ltd. | 85.0 | CNY | 33.0300 | 0.147269 | 792.484354 | 3854.88 | 3.85% |
| PGR | The Progressive Corporation | 84.0 | USD | 198.4200 | 1.000000 | 19.199293 | 3809.52 | 3.81% |
| RJF | Raymond James Financial, Inc. | 83.0 | USD | 153.4800 | 1.000000 | 24.525491 | 3764.17 | 3.76% |
| RMD | ResMed Inc. | 82.0 | USD | 203.7900 | 1.000000 | 18.248299 | 3718.82 | 3.72% |
| 002027.SZ | Focus Media Information Technology Co., Ltd. | 82.0 | CNY | 6.0300 | 0.147269 | 4187.712758 | 3718.82 | 3.72% |
| DECK | Deckers Outdoor Corporation | 79.0 | USD | 94.8900 | 1.000000 | 37.757050 | 3582.77 | 3.58% |
| BKNG | Booking Holdings Inc. | 78.0 | USD | 157.8000 | 1.000000 | 22.417078 | 3537.41 | 3.54% |
| 600660.SS | XD福耀玻 | 78.0 | CNY | 57.1400 | 0.147269 | 420.372901 | 3537.41 | 3.54% |
| 000975.SZ | Shanjin International Gold Co., Ltd. | 78.0 | CNY | 27.7800 | 0.147269 | 864.654699 | 3537.41 | 3.54% |
| META | Meta Platforms, Inc. | 77.0 | USD | 598.8600 | 1.000000 | 5.831185 | 3492.06 | 3.49% |
| AMP | Ameriprise Financial, Inc. | 77.0 | USD | 470.1200 | 1.000000 | 7.428026 | 3492.06 | 3.49% |
| EG | Everest Group, Ltd. | 77.0 | USD | 351.6700 | 1.000000 | 9.929944 | 3492.06 | 3.49% |
| FDS | FactSet Research Systems Inc. | 77.0 | USD | 215.9200 | 1.000000 | 16.172951 | 3492.06 | 3.49% |
| TRV | The Travelers Companies, Inc. | 77.0 | USD | 298.2600 | 1.000000 | 11.708119 | 3492.06 | 3.49% |
| 600989.SS | 宝丰能源 | 77.0 | CNY | 28.4700 | 0.147269 | 832.882243 | 3492.06 | 3.49% |
| CB | Chubb Limited | 76.0 | USD | 322.0400 | 1.000000 | 10.702745 | 3446.71 | 3.45% |
| CINF | Cincinnati Financial Corporation | 76.0 | USD | 163.7900 | 1.000000 | 21.043483 | 3446.71 | 3.45% |
| INTU | Intuit Inc. | 75.0 | USD | 393.2900 | 1.000000 | 8.648480 | 3401.36 | 3.40% |
| ADP | Automatic Data Processing, Inc. | 75.0 | USD | 211.6700 | 1.000000 | 16.069167 | 3401.36 | 3.40% |
| LULU | lululemon athletica inc. | 75.0 | USD | 125.1300 | 1.000000 | 27.182614 | 3401.36 | 3.40% |
| AOS | A. O. Smith Corporation | 75.0 | USD | 58.0900 | 1.000000 | 58.553289 | 3401.36 | 3.40% |
| WRB | W. R. Berkley Corporation | 75.0 | USD | 66.5600 | 1.000000 | 51.102172 | 3401.36 | 3.40% |
| 000651.SZ | 格力电器 | 75.0 | CNY | 40.3000 | 0.147269 | 573.108120 | 3401.36 | 3.40% |
| 601225.SS | 陕西煤业 | 75.0 | CNY | 23.4500 | 0.147269 | 984.915022 | 3401.36 | 3.40% |
| 600809.SS | 山西汾酒 | 75.0 | CNY | 133.8000 | 0.147269 | 172.617767 | 3401.36 | 3.40% |
