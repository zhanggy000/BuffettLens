# Latest Portfolio Report: 20260513_192933_20260513_181314_ndx100+sp500+csi300_limitall_score60_score75_cash100000USD_score_weighted

- Date: 2026-05-13
- Base currency: USD
- Initial cash: 100000.00 USD
- Portfolio value: 100000.00 USD
- Portfolio return: 0.00%
- SPY return: 0.00%
- QQQ return: 0.00%
- Excess vs SPY: 0.00%
- Excess vs QQQ: 0.00%

> Simulated fractional-share portfolio. Values are converted to the base currency using FX rates from Yahoo Finance.

| Ticker | Name | Score | CCY | Buy Price | Current Price | FX to Base | Shares | Value | Return |
|---|---|---:|---|---:|---:|---:|---:|---:|---:|
| HIG | The Hartford Insurance Group, Inc. | 89.0 | USD | 133.1100 | 133.1100 | 1.000000 | 30.322900 | 4036.28 | 0.00% |
| ACGL | Arch Capital Group Ltd. | 88.0 | USD | 94.3100 | 94.3100 | 1.000000 | 42.317142 | 3990.93 | 0.00% |
| ADBE | Adobe Inc. | 85.0 | USD | 246.1500 | 246.1500 | 1.000000 | 15.660676 | 3854.88 | 0.00% |
| 002001.SZ | Zhejiang NHU Company Ltd. | 85.0 | CNY | 33.0300 | 33.0300 | 0.147269 | 792.484354 | 3854.88 | 0.00% |
| PGR | The Progressive Corporation | 84.0 | USD | 198.4200 | 198.4200 | 1.000000 | 19.199293 | 3809.52 | 0.00% |
| RJF | Raymond James Financial, Inc. | 83.0 | USD | 153.4800 | 153.4800 | 1.000000 | 24.525491 | 3764.17 | -0.00% |
| 002027.SZ | Focus Media Information Technology Co., Ltd. | 82.0 | CNY | 6.0300 | 6.0300 | 0.147269 | 4187.712758 | 3718.82 | 0.00% |
| RMD | ResMed Inc. | 82.0 | USD | 203.7900 | 203.7900 | 1.000000 | 18.248299 | 3718.82 | -0.00% |
| DECK | Deckers Outdoor Corporation | 79.0 | USD | 94.8900 | 94.8900 | 1.000000 | 37.757050 | 3582.77 | 0.00% |
| BKNG | Booking Holdings Inc. | 78.0 | USD | 157.8000 | 157.8000 | 1.000000 | 22.417078 | 3537.41 | 0.00% |
| 600660.SS | XD福耀玻 | 78.0 | CNY | 57.1400 | 57.1400 | 0.147269 | 420.372901 | 3537.41 | 0.00% |
| 000975.SZ | Shanjin International Gold Co., Ltd. | 78.0 | CNY | 27.7800 | 27.7800 | 0.147269 | 864.654699 | 3537.41 | 0.00% |
| META | Meta Platforms, Inc. | 77.0 | USD | 598.8600 | 598.8600 | 1.000000 | 5.831185 | 3492.06 | 0.00% |
| AMP | Ameriprise Financial, Inc. | 77.0 | USD | 470.1200 | 470.1200 | 1.000000 | 7.428026 | 3492.06 | 0.00% |
| EG | Everest Group, Ltd. | 77.0 | USD | 351.6700 | 351.6700 | 1.000000 | 9.929944 | 3492.06 | 0.00% |
| FDS | FactSet Research Systems Inc. | 77.0 | USD | 215.9200 | 215.9200 | 1.000000 | 16.172951 | 3492.06 | 0.00% |
| TRV | The Travelers Companies, Inc. | 77.0 | USD | 298.2600 | 298.2600 | 1.000000 | 11.708119 | 3492.06 | 0.00% |
| 600989.SS | 宝丰能源 | 77.0 | CNY | 28.4700 | 28.4700 | 0.147269 | 832.882243 | 3492.06 | 0.00% |
| CB | Chubb Limited | 76.0 | USD | 322.0400 | 322.0400 | 1.000000 | 10.702745 | 3446.71 | 0.00% |
| CINF | Cincinnati Financial Corporation | 76.0 | USD | 163.7900 | 163.7900 | 1.000000 | 21.043483 | 3446.71 | 0.00% |
| INTU | Intuit Inc. | 75.0 | USD | 393.2900 | 393.2900 | 1.000000 | 8.648480 | 3401.36 | 0.00% |
| LULU | lululemon athletica inc. | 75.0 | USD | 125.1300 | 125.1300 | 1.000000 | 27.182614 | 3401.36 | 0.00% |
| AOS | A. O. Smith Corporation | 75.0 | USD | 58.0900 | 58.0900 | 1.000000 | 58.553289 | 3401.36 | 0.00% |
| WRB | W. R. Berkley Corporation | 75.0 | USD | 66.5600 | 66.5600 | 1.000000 | 51.102172 | 3401.36 | 0.00% |
| 601225.SS | 陕西煤业 | 75.0 | CNY | 23.4500 | 23.4500 | 0.147269 | 984.915022 | 3401.36 | 0.00% |
| 600809.SS | 山西汾酒 | 75.0 | CNY | 133.8000 | 133.8000 | 0.147269 | 172.617767 | 3401.36 | 0.00% |
| ADP | Automatic Data Processing, Inc. | 75.0 | USD | 211.6700 | 211.6700 | 1.000000 | 16.069167 | 3401.36 | -0.00% |
| 000651.SZ | 格力电器 | 75.0 | CNY | 40.3000 | 40.3000 | 0.147269 | 573.108120 | 3401.36 | -0.00% |
